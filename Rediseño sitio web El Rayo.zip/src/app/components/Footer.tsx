import { Link } from 'react-router';
import { Phone, MapPin, Clock, Zap } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#0C2340] text-white mt-12">
      <div className="px-4 py-8">
        {/* Logo y descripción */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <div className="bg-gradient-to-br from-[#1E5FA0] to-[#85B7EB] p-2 rounded-lg">
              <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <span className="font-semibold text-lg">El Rayo</span>
          </div>
          <p className="text-sm text-gray-300 leading-relaxed">
            15 años de experiencia en venta de autos seminuevos, motos y servicios de taller mecánico en Ciudad de México.
          </p>
        </div>

        {/* Información de contacto */}
        <div className="space-y-3 mb-6">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#85B7EB] flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="text-gray-300">Ciudad de México</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Phone className="w-5 h-5 text-[#85B7EB] flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <a href="tel:5652189129" className="text-gray-300 hover:text-white transition-colors">
                56 5218 9129
              </a>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-[#85B7EB] flex-shrink-0 mt-0.5" />
            <div className="text-sm text-gray-300">
              <p>Lunes a Viernes: 9:00 - 18:00</p>
              <p>Sábados: 9:00 - 14:00</p>
            </div>
          </div>
        </div>

        {/* Enlaces rápidos */}
        <div className="border-t border-[#1E5FA0] pt-6 mb-6">
          <h3 className="font-semibold mb-3 text-sm">Enlaces rápidos</h3>
          <nav className="grid grid-cols-2 gap-2">
            <Link to="/autos" className="text-sm text-gray-300 hover:text-white transition-colors">
              Autos
            </Link>
            <Link to="/motos" className="text-sm text-gray-300 hover:text-white transition-colors">
              Motos
            </Link>
            <Link to="/servicios" className="text-sm text-gray-300 hover:text-white transition-colors">
              Servicios
            </Link>
            <Link to="/agendar-cita" className="text-sm text-gray-300 hover:text-white transition-colors">
              Agendar Cita
            </Link>
            <Link to="/contacto" className="text-sm text-gray-300 hover:text-white transition-colors">
              Contacto
            </Link>
            <Link to="/justificacion-ux" className="text-sm text-[#85B7EB] hover:text-white transition-colors">
              Ver Justificación UX
            </Link>
          </nav>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#1E5FA0] pt-6 text-center">
          <p className="text-sm text-gray-400">
            © {new Date().getFullYear()} El Rayo. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}