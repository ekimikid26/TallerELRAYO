import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { Menu, X, Zap } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Inicio' },
    { path: '/autos', label: 'Autos' },
    { path: '/motos', label: 'Motos' },
    { path: '/servicios', label: 'Servicios' },
    { path: '/agendar-cita', label: 'Agendar Cita' },
    { path: '/contacto', label: 'Contacto' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-[#0C2340] text-white sticky top-0 z-50 shadow-md">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-gradient-to-br from-[#1E5FA0] to-[#85B7EB] p-2 rounded-lg">
            <Zap className="w-6 h-6 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-semibold text-lg">El Rayo</span>
        </Link>

        {/* Hamburger Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-2 hover:bg-[#1E5FA0] rounded-lg transition-colors"
          aria-label="Menú"
        >
          {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <nav className="border-t border-[#1E5FA0] bg-[#0C2340]">
          <ul className="py-2">
            {navLinks.map((link) => (
              <li key={link.path}>
                <Link
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-4 py-3 hover:bg-[#1E5FA0] transition-colors ${
                    isActive(link.path) ? 'bg-[#1E5FA0] font-semibold' : ''
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}
