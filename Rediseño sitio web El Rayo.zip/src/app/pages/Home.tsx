import { Link } from 'react-router';
import { Car, Bike, Wrench, Calendar, Phone, CheckCircle, Clock, Shield, FileText } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';
import { autos, motos } from '../data/vehicles';

export function Home() {
  const featuredAutos = autos.slice(0, 3);
  const featuredMotos = motos.slice(0, 2);

  const whatsappContact = () => {
    const phoneNumber = '5652189129';
    const message = encodeURIComponent('Hola, me gustaría obtener más información.');
    window.open(`https://wa.me/52${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* BANNER INFORMATIVO - JUSTIFICACIÓN UX */}
      <div className="bg-[#85B7EB] px-4 py-3">
        <div className="max-w-xl mx-auto">
          <Link
            to="/justificacion-ux"
            className="flex items-center justify-between gap-3 text-[#0C2340] hover:text-[#1E5FA0] transition-colors"
          >
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-semibold">Ver Justificación UX del Rediseño</span>
            </div>
            <span className="text-sm">→</span>
          </Link>
        </div>
      </div>

      {/* HERO SECTION */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-12">
        <div className="max-w-xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">
            Autos y Motos Seminuevos de Confianza
          </h1>
          <p className="text-lg mb-6 text-gray-200">
            15 años de experiencia en Ciudad de México. Encuentra tu vehículo ideal y servicio de taller especializado.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/autos"
              className="bg-white text-[#0C2340] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Ver Autos
            </Link>
            <button
              onClick={whatsappContact}
              className="bg-[#25D366] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#20BA5A] transition-colors"
            >
              Contactar por WhatsApp
            </button>
          </div>
        </div>
      </section>

      {/* SERVICIOS DESTACADOS */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6 text-center">
            Nuestros Servicios
          </h2>
          <div className="grid gap-4">
            <Link
              to="/autos"
              className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200"
            >
              <div className="flex items-start gap-4">
                <div className="bg-[#0C2340] p-3 rounded-lg">
                  <Car className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-[#0C2340] mb-1">Autos Seminuevos</h3>
                  <p className="text-sm text-gray-600">
                    Vehículos verificados con historial completo
                  </p>
                </div>
              </div>
            </Link>

            <Link
              to="/motos"
              className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200"
            >
              <div className="flex items-start gap-4">
                <div className="bg-[#0C2340] p-3 rounded-lg">
                  <Bike className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-[#0C2340] mb-1">Motos</h3>
                  <p className="text-sm text-gray-600">
                    Motocicletas en excelente estado
                  </p>
                </div>
              </div>
            </Link>

            <Link
              to="/servicios"
              className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200"
            >
              <div className="flex items-start gap-4">
                <div className="bg-[#1E5FA0] p-3 rounded-lg">
                  <Wrench className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-[#0C2340] mb-1">Taller Mecánico</h3>
                  <p className="text-sm text-gray-600">
                    Servicio especializado para tu vehículo
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* AUTOS DESTACADOS */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-[#0C2340]">Autos Destacados</h2>
            <Link to="/autos" className="text-[#1E5FA0] font-semibold text-sm">
              Ver todos
            </Link>
          </div>
          <div className="grid gap-4">
            {featuredAutos.map((auto) => (
              <Link
                key={auto.id}
                to={`/autos/${auto.id}`}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200 overflow-hidden"
              >
                <img
                  src={auto.imagen}
                  alt={`${auto.marca} ${auto.modelo}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-[#0C2340] mb-1">
                    {auto.marca} {auto.modelo} {auto.año}
                  </h3>
                  <p className="text-2xl font-bold text-[#1E5FA0] mb-2">
                    ${auto.precio.toLocaleString('es-MX')}
                  </p>
                  <div className="flex gap-3 text-sm text-gray-600">
                    <span>{auto.kilometraje.toLocaleString('es-MX')} km</span>
                    <span>•</span>
                    <span>{auto.transmision}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* MOTOS DESTACADAS */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-[#0C2340]">Motos Destacadas</h2>
            <Link to="/motos" className="text-[#1E5FA0] font-semibold text-sm">
              Ver todas
            </Link>
          </div>
          <div className="grid gap-4">
            {featuredMotos.map((moto) => (
              <Link
                key={moto.id}
                to={`/motos/${moto.id}`}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200 overflow-hidden"
              >
                <img
                  src={moto.imagen}
                  alt={`${moto.marca} ${moto.modelo}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-[#0C2340] mb-1">
                    {moto.marca} {moto.modelo} {moto.año}
                  </h3>
                  <p className="text-2xl font-bold text-[#1E5FA0] mb-2">
                    ${moto.precio.toLocaleString('es-MX')}
                  </p>
                  <div className="flex gap-3 text-sm text-gray-600">
                    <span>{moto.kilometraje.toLocaleString('es-MX')} km</span>
                    <span>•</span>
                    <span>{moto.cilindrada}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* POR QUÉ ELEGIRNOS */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6 text-center">
            ¿Por Qué Elegirnos?
          </h2>
          <div className="space-y-4">
            <div className="flex gap-4">
              <CheckCircle className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">15 Años de Experiencia</h3>
                <p className="text-sm text-gray-600">
                  Trayectoria comprobada en el mercado automotriz de CDMX
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Shield className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Vehículos Verificados</h3>
                <p className="text-sm text-gray-600">
                  Todos nuestros autos y motos pasan por inspección completa
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Wrench className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Taller Especializado</h3>
                <p className="text-sm text-gray-600">
                  Servicio de mantenimiento y reparación profesional
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Clock className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Atención Personalizada</h3>
                <p className="text-sm text-gray-600">
                  Te asesoramos en todo el proceso de compra y servicio
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="px-4 py-12 bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white">
        <div className="max-w-xl mx-auto text-center">
          <Calendar className="w-12 h-12 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-3">¿Listo para tu Próximo Vehículo?</h2>
          <p className="text-gray-200 mb-6">
            Agenda una cita o visítanos para conocer nuestro inventario completo
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/agendar-cita"
              className="bg-white text-[#0C2340] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Agendar Cita
            </Link>
            <a
              href="tel:5652189129"
              className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-[#0C2340] transition-colors flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Llamar Ahora
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}