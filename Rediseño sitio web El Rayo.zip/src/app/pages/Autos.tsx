import { useState } from 'react';
import { Link } from 'react-router';
import { Filter } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';
import { autos } from '../data/vehicles';

export function Autos() {
  const [transmisionFilter, setTransmisionFilter] = useState<string>('todas');
  const [precioMax, setPrecioMax] = useState<number>(500000);

  const autosFiltrados = autos.filter((auto) => {
    const matchTransmision = transmisionFilter === 'todas' || auto.transmision === transmisionFilter;
    const matchPrecio = auto.precio <= precioMax;
    return matchTransmision && matchPrecio;
  });

  const marcas = Array.from(new Set(autos.map((a) => a.marca))).sort();

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-8">
        <div className="max-w-xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Autos Seminuevos</h1>
          <p className="text-gray-200">
            Encuentra el auto perfecto para ti. Todos nuestros vehículos están verificados y en excelente estado.
          </p>
        </div>
      </section>

      {/* FILTROS */}
      <section className="px-4 py-6 bg-[#f4f6f9] border-b border-gray-200">
        <div className="max-w-xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-[#0C2340]" />
            <h2 className="font-semibold text-[#0C2340]">Filtros</h2>
          </div>
          
          <div className="space-y-4">
            {/* Transmisión */}
            <div>
              <label className="block text-sm font-medium text-[#0C2340] mb-2">
                Transmisión
              </label>
              <select
                value={transmisionFilter}
                onChange={(e) => setTransmisionFilter(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
              >
                <option value="todas">Todas</option>
                <option value="Automática">Automática</option>
                <option value="Manual">Manual</option>
              </select>
            </div>

            {/* Precio Máximo */}
            <div>
              <label className="block text-sm font-medium text-[#0C2340] mb-2">
                Precio máximo: ${precioMax.toLocaleString('es-MX')}
              </label>
              <input
                type="range"
                min="100000"
                max="500000"
                step="10000"
                value={precioMax}
                onChange={(e) => setPrecioMax(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>

          <div className="mt-4 text-sm text-gray-600">
            Mostrando {autosFiltrados.length} de {autos.length} autos
          </div>
        </div>
      </section>

      {/* LISTADO DE AUTOS */}
      <section className="px-4 py-8">
        <div className="max-w-xl mx-auto">
          {autosFiltrados.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600">No se encontraron autos con estos filtros.</p>
              <button
                onClick={() => {
                  setTransmisionFilter('todas');
                  setPrecioMax(500000);
                }}
                className="mt-4 text-[#1E5FA0] font-semibold"
              >
                Limpiar filtros
              </button>
            </div>
          ) : (
            <div className="grid gap-4">
              {autosFiltrados.map((auto) => (
                <Link
                  key={auto.id}
                  to={`/autos/${auto.id}`}
                  className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200 overflow-hidden"
                >
                  <img
                    src={auto.imagen}
                    alt={`${auto.marca} ${auto.modelo}`}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="font-semibold text-[#0C2340] mb-1">
                      {auto.marca} {auto.modelo} {auto.año}
                    </h3>
                    <p className="text-2xl font-bold text-[#1E5FA0] mb-3">
                      ${auto.precio.toLocaleString('es-MX')}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                      <div>
                        <span className="text-gray-500">Kilometraje:</span>
                        <p className="font-medium text-[#0C2340]">
                          {auto.kilometraje.toLocaleString('es-MX')} km
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Transmisión:</span>
                        <p className="font-medium text-[#0C2340]">{auto.transmision}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Combustible:</span>
                        <p className="font-medium text-[#0C2340]">{auto.combustible}</p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <span className="inline-block bg-[#0C2340] text-white px-4 py-2 rounded-lg text-sm font-semibold">
                        Ver detalles
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-xl font-bold text-[#0C2340] mb-3">
            ¿No Encuentras lo que Buscas?
          </h2>
          <p className="text-gray-600 mb-6">
            Contáctanos y te ayudaremos a encontrar el auto ideal para ti
          </p>
          <Link
            to="/contacto"
            className="inline-block bg-[#1E5FA0] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#0C2340] transition-colors"
          >
            Contactar
          </Link>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
