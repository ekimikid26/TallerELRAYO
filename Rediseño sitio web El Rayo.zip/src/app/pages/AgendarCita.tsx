import { useState } from 'react';
import { Calendar, CheckCircle } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';

export function AgendarCita() {
  const [formData, setFormData] = useState({
    nombre: '',
    telefono: '',
    email: '',
    servicio: '',
    fecha: '',
    hora: '',
    mensaje: '',
  });

  const servicios = [
    'Mantenimiento Preventivo',
    'Reparación Mecánica',
    'Frenos y Suspensión',
    'Inspección Pre-Compra',
    'Prueba de Manejo (Autos)',
    'Visita (Motos)',
    'Otro',
  ];

  const horarios = [
    '9:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const phoneNumber = '5652189129';
    const mensaje = `Hola, me gustaría agendar una cita:

*Nombre:* ${formData.nombre}
*Teléfono:* ${formData.telefono}
*Email:* ${formData.email}
*Servicio:* ${formData.servicio}
*Fecha:* ${formData.fecha}
*Hora:* ${formData.hora}
${formData.mensaje ? `*Mensaje:* ${formData.mensaje}` : ''}

Quedo atento a su confirmación.`;

    const whatsappUrl = `https://wa.me/52${phoneNumber}?text=${encodeURIComponent(mensaje)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Obtener fecha mínima (hoy)
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-8">
        <div className="max-w-xl mx-auto text-center">
          <Calendar className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold mb-2">Agendar Cita</h1>
          <p className="text-gray-200">
            Completa el formulario y te contactaremos por WhatsApp para confirmar tu cita
          </p>
        </div>
      </section>

      {/* FORMULARIO */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Nombre */}
            <div>
              <label htmlFor="nombre" className="block text-sm font-medium text-[#0C2340] mb-2">
                Nombre completo *
              </label>
              <input
                type="text"
                id="nombre"
                name="nombre"
                required
                value={formData.nombre}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
                placeholder="Juan Pérez"
              />
            </div>

            {/* Teléfono */}
            <div>
              <label htmlFor="telefono" className="block text-sm font-medium text-[#0C2340] mb-2">
                Teléfono *
              </label>
              <input
                type="tel"
                id="telefono"
                name="telefono"
                required
                value={formData.telefono}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
                placeholder="55 1234 5678"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[#0C2340] mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
                placeholder="correo@ejemplo.com"
              />
            </div>

            {/* Servicio */}
            <div>
              <label htmlFor="servicio" className="block text-sm font-medium text-[#0C2340] mb-2">
                Servicio solicitado *
              </label>
              <select
                id="servicio"
                name="servicio"
                required
                value={formData.servicio}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
              >
                <option value="">Selecciona un servicio</option>
                {servicios.map((servicio) => (
                  <option key={servicio} value={servicio}>
                    {servicio}
                  </option>
                ))}
              </select>
            </div>

            {/* Fecha */}
            <div>
              <label htmlFor="fecha" className="block text-sm font-medium text-[#0C2340] mb-2">
                Fecha preferida *
              </label>
              <input
                type="date"
                id="fecha"
                name="fecha"
                required
                min={today}
                value={formData.fecha}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
              />
            </div>

            {/* Hora */}
            <div>
              <label htmlFor="hora" className="block text-sm font-medium text-[#0C2340] mb-2">
                Hora preferida *
              </label>
              <select
                id="hora"
                name="hora"
                required
                value={formData.hora}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
              >
                <option value="">Selecciona una hora</option>
                {horarios.map((hora) => (
                  <option key={hora} value={hora}>
                    {hora}
                  </option>
                ))}
              </select>
            </div>

            {/* Mensaje adicional */}
            <div>
              <label htmlFor="mensaje" className="block text-sm font-medium text-[#0C2340] mb-2">
                Mensaje adicional (opcional)
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows={4}
                value={formData.mensaje}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E5FA0]"
                placeholder="Información adicional sobre tu vehículo o servicio requerido"
              />
            </div>

            {/* Botón submit */}
            <button
              type="submit"
              className="w-full bg-[#25D366] text-white px-6 py-4 rounded-lg font-semibold hover:bg-[#20BA5A] transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Enviar Solicitud por WhatsApp
            </button>
          </form>

          {/* Nota informativa */}
          <div className="mt-6 bg-[#f4f6f9] p-4 rounded-lg">
            <p className="text-sm text-gray-600">
              <strong className="text-[#0C2340]">Nota:</strong> Al enviar este formulario, serás redirigido a WhatsApp para confirmar tu cita directamente con nosotros. Te responderemos lo antes posible.
            </p>
          </div>
        </div>
      </section>

      {/* INFORMACIÓN ADICIONAL */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <h2 className="text-xl font-bold text-[#0C2340] mb-4 text-center">
            Horarios de Atención
          </h2>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Lunes a Viernes</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 18:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Sábados</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 14:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Domingos</span>
                <span className="font-semibold text-gray-500">Cerrado</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
