import { useState } from 'react';
import { Link } from 'react-router';
import { Filter } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';
import { motos } from '../data/vehicles';

export function Motos() {
  const [precioMax, setPrecioMax] = useState<number>(60000);

  const motosFiltradas = motos.filter((moto) => moto.precio <= precioMax);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-8">
        <div className="max-w-xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Motos</h1>
          <p className="text-gray-200">
            Motocicletas en excelente estado. Ideales para ciudad o trabajo.
          </p>
        </div>
      </section>

      {/* FILTROS */}
      <section className="px-4 py-6 bg-[#f4f6f9] border-b border-gray-200">
        <div className="max-w-xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-[#0C2340]" />
            <h2 className="font-semibold text-[#0C2340]">Filtros</h2>
          </div>
          
          <div className="space-y-4">
            {/* Precio Máximo */}
            <div>
              <label className="block text-sm font-medium text-[#0C2340] mb-2">
                Precio máximo: ${precioMax.toLocaleString('es-MX')}
              </label>
              <input
                type="range"
                min="10000"
                max="60000"
                step="5000"
                value={precioMax}
                onChange={(e) => setPrecioMax(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>

          <div className="mt-4 text-sm text-gray-600">
            Mostrando {motosFiltradas.length} de {motos.length} motos
          </div>
        </div>
      </section>

      {/* LISTADO DE MOTOS */}
      <section className="px-4 py-8">
        <div className="max-w-xl mx-auto">
          {motosFiltradas.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600">No se encontraron motos con estos filtros.</p>
              <button
                onClick={() => setPrecioMax(60000)}
                className="mt-4 text-[#1E5FA0] font-semibold"
              >
                Limpiar filtros
              </button>
            </div>
          ) : (
            <div className="grid gap-4">
              {motosFiltradas.map((moto) => (
                <Link
                  key={moto.id}
                  to={`/motos/${moto.id}`}
                  className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200 overflow-hidden"
                >
                  <img
                    src={moto.imagen}
                    alt={`${moto.marca} ${moto.modelo}`}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="font-semibold text-[#0C2340] mb-1">
                      {moto.marca} {moto.modelo} {moto.año}
                    </h3>
                    <p className="text-2xl font-bold text-[#1E5FA0] mb-3">
                      ${moto.precio.toLocaleString('es-MX')}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                      <div>
                        <span className="text-gray-500">Kilometraje:</span>
                        <p className="font-medium text-[#0C2340]">
                          {moto.kilometraje.toLocaleString('es-MX')} km
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Cilindrada:</span>
                        <p className="font-medium text-[#0C2340]">{moto.cilindrada}</p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <span className="inline-block bg-[#0C2340] text-white px-4 py-2 rounded-lg text-sm font-semibold">
                        Ver detalles
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-xl font-bold text-[#0C2340] mb-3">
            ¿No Encuentras lo que Buscas?
          </h2>
          <p className="text-gray-600 mb-6">
            Contáctanos y te ayudaremos a encontrar la moto ideal para ti
          </p>
          <Link
            to="/contacto"
            className="inline-block bg-[#1E5FA0] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#0C2340] transition-colors"
          >
            Contactar
          </Link>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
