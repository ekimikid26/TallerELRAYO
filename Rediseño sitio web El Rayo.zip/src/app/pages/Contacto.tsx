import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';

export function Contacto() {
  const contactarWhatsApp = () => {
    const phoneNumber = '5652189129';
    const message = encodeURIComponent('Hola, me gustaría obtener más información sobre sus servicios.');
    window.open(`https://wa.me/52${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-8">
        <div className="max-w-xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-2">Contáctanos</h1>
          <p className="text-gray-200">
            Estamos aquí para ayudarte. Comunícate con nosotros por cualquiera de estos medios.
          </p>
        </div>
      </section>

      {/* INFORMACIÓN DE CONTACTO */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6">Información de Contacto</h2>
          
          <div className="space-y-4">
            {/* WhatsApp */}
            <button
              onClick={contactarWhatsApp}
              className="w-full bg-[#25D366] text-white p-5 rounded-lg hover:bg-[#20BA5A] transition-colors text-left"
            >
              <div className="flex items-start gap-4">
                <MessageCircle className="w-6 h-6 flex-shrink-0 mt-1" fill="white" />
                <div>
                  <h3 className="font-semibold mb-1">WhatsApp (Recomendado)</h3>
                  <p className="text-sm opacity-90">56 5218 9129</p>
                  <p className="text-sm opacity-75 mt-1">Toca aquí para abrir WhatsApp</p>
                </div>
              </div>
            </button>

            {/* Teléfono */}
            <a
              href="tel:5652189129"
              className="block bg-white border border-gray-200 p-5 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-4">
                <Phone className="w-6 h-6 text-[#1E5FA0] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-[#0C2340] mb-1">Teléfono</h3>
                  <p className="text-gray-700">56 5218 9129</p>
                  <p className="text-sm text-gray-500 mt-1">Lunes a Viernes: 9:00 - 18:00</p>
                </div>
              </div>
            </a>

            {/* Ubicación */}
            <div className="bg-white border border-gray-200 p-5 rounded-lg">
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-[#1E5FA0] flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="font-semibold text-[#0C2340] mb-1">Ubicación</h3>
                  <p className="text-gray-700 mb-3">Ciudad de México</p>
                  <a
                    href="https://maps.google.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-[#0C2340] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-[#1E5FA0] transition-colors"
                  >
                    Ver en Google Maps
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HORARIOS */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Clock className="w-6 h-6 text-[#1E5FA0]" />
            <h2 className="text-2xl font-bold text-[#0C2340]">Horarios de Atención</h2>
          </div>
          
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-gray-200">
                <span className="text-gray-700">Lunes a Viernes</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 18:00</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-gray-200">
                <span className="text-gray-700">Sábados</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 14:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Domingos</span>
                <span className="font-semibold text-gray-500">Cerrado</span>
              </div>
            </div>
          </div>

          <div className="mt-4 bg-[#0C2340] text-white p-4 rounded-lg">
            <p className="text-sm">
              <strong>Nota:</strong> Preferimos contacto por WhatsApp para una atención más rápida y personalizada.
            </p>
          </div>
        </div>
      </section>

      {/* MAPA (Placeholder) */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6">Nuestra Ubicación</h2>
          <div className="bg-gray-200 rounded-lg overflow-hidden" style={{ height: '300px' }}>
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center h-full bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white hover:opacity-90 transition-opacity"
            >
              <div className="text-center">
                <MapPin className="w-12 h-12 mx-auto mb-3" />
                <p className="font-semibold mb-2">Ver Ubicación en Google Maps</p>
                <p className="text-sm text-gray-200">Toca aquí para abrir el mapa</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* PREGUNTAS FRECUENTES */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6">Preguntas Frecuentes</h2>
          
          <div className="space-y-4">
            <div className="bg-white p-5 rounded-lg border border-gray-200">
              <h3 className="font-semibold text-[#0C2340] mb-2">
                ¿Aceptan pagos con tarjeta?
              </h3>
              <p className="text-sm text-gray-600">
                Aceptamos efectivo y transferencias bancarias. Consulta disponibilidad de pago con tarjeta.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg border border-gray-200">
              <h3 className="font-semibold text-[#0C2340] mb-2">
                ¿Necesito agendar cita?
              </h3>
              <p className="text-sm text-gray-600">
                Se recomienda agendar cita para garantizar disponibilidad, especialmente para servicios de taller.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg border border-gray-200">
              <h3 className="font-semibold text-[#0C2340] mb-2">
                ¿Los autos cuentan con garantía?
              </h3>
              <p className="text-sm text-gray-600">
                Nuestros vehículos están verificados. Consultanos sobre opciones de garantía disponibles.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg border border-gray-200">
              <h3 className="font-semibold text-[#0C2340] mb-2">
                ¿Hacen pruebas de manejo?
              </h3>
              <p className="text-sm text-gray-600">
                Sí, puedes agendar una prueba de manejo sin compromiso. Contactanos para coordinar.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="px-4 py-12 bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-3">¿Tienes Más Preguntas?</h2>
          <p className="text-gray-200 mb-6">
            No dudes en contactarnos. Estamos para ayudarte.
          </p>
          <button
            onClick={contactarWhatsApp}
            className="bg-[#25D366] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#20BA5A] transition-colors inline-flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Contactar por WhatsApp
          </button>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
