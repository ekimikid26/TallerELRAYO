import { Link } from 'react-router';
import { Wrench, CheckCircle, Clock, Shield, Settings, Car } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';

export function Servicios() {
  const servicios = [
    {
      id: 1,
      icono: Settings,
      titulo: 'Mantenimiento Preventivo',
      descripcion: 'Cambio de aceite, filtros, revisión general de sistemas.',
      precio: 'Desde $800',
      items: ['Cambio de aceite y filtro', 'Revisión de frenos', 'Revisión de suspensión', 'Revisión de luces'],
    },
    {
      id: 2,
      icono: Wrench,
      titulo: 'Reparaciones Mecánicas',
      descripcion: 'Diagnóstico y reparación de motor, transmisión y sistemas eléctricos.',
      precio: 'Cotización según diagnóstico',
      items: ['Diagnóstico computarizado', 'Reparación de motor', 'Reparación de transmisión', 'Sistema eléctrico'],
    },
    {
      id: 3,
      icono: Car,
      titulo: 'Frenos y Suspensión',
      descripcion: 'Cambio de balatas, discos, amortiguadores y componentes de suspensión.',
      precio: 'Desde $1,200',
      items: ['Cambio de balatas', 'Cambio de discos', 'Amortiguadores', 'Alineación y balanceo'],
    },
    {
      id: 4,
      icono: Shield,
      titulo: 'Inspección Pre-Compra',
      descripcion: 'Revisión completa antes de comprar un auto usado.',
      precio: '$600',
      items: ['Revisión mecánica completa', 'Verificación de documentos', 'Reporte detallado', 'Recomendaciones'],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* HERO */}
      <section className="bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white px-4 py-8">
        <div className="max-w-xl mx-auto text-center">
          <Wrench className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold mb-2">Servicios de Taller</h1>
          <p className="text-gray-200">
            Mantenimiento y reparación especializada para tu vehículo. 15 años de experiencia.
          </p>
        </div>
      </section>

      {/* SERVICIOS */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6">Nuestros Servicios</h2>
          <div className="space-y-6">
            {servicios.map((servicio) => {
              const Icono = servicio.icono;
              return (
                <div
                  key={servicio.id}
                  className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="bg-[#0C2340] p-3 rounded-lg">
                      <Icono className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-[#0C2340] mb-1">{servicio.titulo}</h3>
                      <p className="text-sm text-gray-600 mb-2">{servicio.descripcion}</p>
                      <p className="text-lg font-bold text-[#1E5FA0]">{servicio.precio}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {servicio.items.map((item, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-[#1E5FA0] flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* POR QUÉ NUESTRO TALLER */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6 text-center">
            ¿Por Qué Elegir Nuestro Taller?
          </h2>
          <div className="space-y-4">
            <div className="flex gap-4 bg-white p-4 rounded-lg">
              <Shield className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Mecánicos Certificados</h3>
                <p className="text-sm text-gray-600">
                  Personal capacitado con años de experiencia en el sector automotriz
                </p>
              </div>
            </div>
            <div className="flex gap-4 bg-white p-4 rounded-lg">
              <CheckCircle className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Refacciones de Calidad</h3>
                <p className="text-sm text-gray-600">
                  Utilizamos refacciones originales o de primera calidad
                </p>
              </div>
            </div>
            <div className="flex gap-4 bg-white p-4 rounded-lg">
              <Clock className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Tiempos de Entrega</h3>
                <p className="text-sm text-gray-600">
                  Trabajos realizados en tiempo y forma, sin demoras innecesarias
                </p>
              </div>
            </div>
            <div className="flex gap-4 bg-white p-4 rounded-lg">
              <Wrench className="w-6 h-6 text-[#1E5FA0] flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#0C2340] mb-1">Diagnóstico Gratuito</h3>
                <p className="text-sm text-gray-600">
                  Evaluación inicial sin costo para determinar el trabajo necesario
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HORARIOS */}
      <section className="px-4 py-12">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-[#0C2340] mb-6 text-center">
            Horarios de Atención
          </h2>
          <div className="bg-[#f4f6f9] p-6 rounded-lg">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Lunes a Viernes</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 18:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Sábados</span>
                <span className="font-semibold text-[#0C2340]">9:00 - 14:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Domingos</span>
                <span className="font-semibold text-gray-500">Cerrado</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 py-12 bg-gradient-to-br from-[#0C2340] to-[#1E5FA0] text-white">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-3">¿Necesitas Servicio para tu Vehículo?</h2>
          <p className="text-gray-200 mb-6">
            Agenda una cita o contáctanos para más información sobre nuestros servicios
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/agendar-cita"
              className="bg-white text-[#0C2340] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Agendar Cita
            </Link>
            <Link
              to="/contacto"
              className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-[#0C2340] transition-colors"
            >
              Contactar
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
