import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { ChevronLeft, Phone, MessageCircle, CheckCircle, Calendar } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { WhatsAppButton } from '../components/WhatsAppButton';
import { autos } from '../data/vehicles';

export function AutoDetalle() {
  const { id } = useParams();
  const auto = autos.find((a) => a.id === id);
  const [imagenActual, setImagenActual] = useState(0);

  if (!auto) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-[#0C2340] mb-4">Auto no encontrado</h1>
          <Link to="/autos" className="text-[#1E5FA0] font-semibold">
            Volver al catálogo
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const contactarWhatsApp = () => {
    const phoneNumber = '5652189129';
    const message = encodeURIComponent(
      `Hola, me interesa el ${auto.marca} ${auto.modelo} ${auto.año}. ¿Podría darme más información?`
    );
    window.open(`https://wa.me/52${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Botón volver */}
      <div className="px-4 py-4 bg-[#f4f6f9] border-b border-gray-200">
        <div className="max-w-xl mx-auto">
          <Link to="/autos" className="flex items-center gap-2 text-[#1E5FA0] font-semibold">
            <ChevronLeft className="w-5 h-5" />
            Volver al catálogo
          </Link>
        </div>
      </div>

      {/* Galería de imágenes */}
      <section className="bg-black">
        <div className="max-w-xl mx-auto">
          <img
            src={auto.imagenes[imagenActual]}
            alt={`${auto.marca} ${auto.modelo}`}
            className="w-full h-64 object-contain"
          />
          {auto.imagenes.length > 1 && (
            <div className="flex gap-2 p-4 bg-black justify-center">
              {auto.imagenes.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setImagenActual(index)}
                  className={`w-16 h-16 rounded border-2 overflow-hidden ${
                    imagenActual === index ? 'border-[#1E5FA0]' : 'border-gray-600'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Información principal */}
      <section className="px-4 py-6">
        <div className="max-w-xl mx-auto">
          <h1 className="text-2xl font-bold text-[#0C2340] mb-2">
            {auto.marca} {auto.modelo} {auto.año}
          </h1>
          <p className="text-3xl font-bold text-[#1E5FA0] mb-6">
            ${auto.precio.toLocaleString('es-MX')}
          </p>

          {/* Especificaciones clave */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-[#f4f6f9] p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Kilometraje</p>
              <p className="font-semibold text-[#0C2340]">
                {auto.kilometraje.toLocaleString('es-MX')} km
              </p>
            </div>
            <div className="bg-[#f4f6f9] p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Año</p>
              <p className="font-semibold text-[#0C2340]">{auto.año}</p>
            </div>
            <div className="bg-[#f4f6f9] p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Transmisión</p>
              <p className="font-semibold text-[#0C2340]">{auto.transmision}</p>
            </div>
            <div className="bg-[#f4f6f9] p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Combustible</p>
              <p className="font-semibold text-[#0C2340]">{auto.combustible}</p>
            </div>
          </div>

          {/* Descripción */}
          <div className="mb-6">
            <h2 className="text-xl font-bold text-[#0C2340] mb-3">Descripción</h2>
            <p className="text-gray-700 leading-relaxed">{auto.descripcion}</p>
          </div>

          {/* Características */}
          <div className="mb-6">
            <h2 className="text-xl font-bold text-[#0C2340] mb-3">Características</h2>
            <div className="space-y-2">
              {auto.caracteristicas.map((caracteristica, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#1E5FA0] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{caracteristica}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Botones fijos */}
      <section className="sticky bottom-0 bg-white border-t border-gray-200 px-4 py-4 shadow-lg">
        <div className="max-w-xl mx-auto grid grid-cols-2 gap-3">
          <a
            href="tel:5652189129"
            className="bg-[#0C2340] text-white px-4 py-3 rounded-lg font-semibold hover:bg-[#1E5FA0] transition-colors flex items-center justify-center gap-2"
          >
            <Phone className="w-5 h-5" />
            Llamar
          </a>
          <button
            onClick={contactarWhatsApp}
            className="bg-[#25D366] text-white px-4 py-3 rounded-lg font-semibold hover:bg-[#20BA5A] transition-colors flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            WhatsApp
          </button>
        </div>
      </section>

      {/* Sección adicional - Agendar prueba de manejo */}
      <section className="px-4 py-12 bg-[#f4f6f9]">
        <div className="max-w-xl mx-auto text-center">
          <Calendar className="w-12 h-12 mx-auto mb-4 text-[#1E5FA0]" />
          <h2 className="text-xl font-bold text-[#0C2340] mb-3">
            ¿Quieres Probar este Auto?
          </h2>
          <p className="text-gray-600 mb-6">
            Agenda una cita para una prueba de manejo sin compromiso
          </p>
          <Link
            to="/agendar-cita"
            className="inline-block bg-[#1E5FA0] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#0C2340] transition-colors"
          >
            Agendar Cita
          </Link>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
