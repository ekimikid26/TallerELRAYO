export interface Auto {
  id: string;
  marca: string;
  modelo: string;
  año: number;
  precio: number;
  kilometraje: number;
  transmision: string;
  combustible: string;
  imagen: string;
  imagenes: string[];
  descripcion: string;
  caracteristicas: string[];
}

export interface Moto {
  id: string;
  marca: string;
  modelo: string;
  año: number;
  precio: number;
  kilometraje: number;
  cilindrada: string;
  imagen: string;
  imagenes: string[];
  descripcion: string;
  caracteristicas: string[];
}

export const autos: Auto[] = [
  {
    id: '1',
    marca: 'Honda',
    modelo: 'Civic',
    año: 2020,
    precio: 285000,
    kilometraje: 45000,
    transmision: 'Automática',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1619405399517-d7fce0f13302?w=800&h=600&fit=crop',
    ],
    descripcion: 'Honda Civic 2020 en excelente estado. Un solo dueño, mantenimiento completo en agencia. Interior impecable, aire acondicionado, sistema de audio premium.',
    caracteristicas: [
      'Un solo dueño',
      'Aire acondicionado',
      'Sistema de audio premium',
      'Bolsas de aire',
      'Frenos ABS',
      'Llantas nuevas',
    ],
  },
  {
    id: '2',
    marca: 'Nissan',
    modelo: 'Versa',
    año: 2019,
    precio: 195000,
    kilometraje: 62000,
    transmision: 'Manual',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1552519507-cf98d4f5bba3?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1552519507-cf98d4f5bba3?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=800&h=600&fit=crop',
    ],
    descripcion: 'Nissan Versa 2019 ideal para ciudad. Económico en gasolina, amplio espacio interior, mantenimiento al día.',
    caracteristicas: [
      'Bajo consumo de combustible',
      'Amplio espacio interior',
      'Aire acondicionado',
      'Bolsas de aire',
      'Mantenimiento al día',
    ],
  },
  {
    id: '3',
    marca: 'Toyota',
    modelo: 'Corolla',
    año: 2021,
    precio: 325000,
    kilometraje: 28000,
    transmision: 'Automática',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1627454820516-daca2f4a5e36?w=800&h=600&fit=crop',
    ],
    descripcion: 'Toyota Corolla 2021 seminuevo. Garantía extendida disponible, sensores de reversa, cámara trasera, pantalla táctil.',
    caracteristicas: [
      'Sensores de reversa',
      'Cámara trasera',
      'Pantalla táctil',
      'Bluetooth',
      'Control crucero',
      'Garantía disponible',
    ],
  },
  {
    id: '4',
    marca: 'Mazda',
    modelo: 'CX-5',
    año: 2018,
    precio: 310000,
    kilometraje: 75000,
    transmision: 'Automática',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1581540222194-0def2dda95b8?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1581540222194-0def2dda95b8?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800&h=600&fit=crop',
    ],
    descripcion: 'Mazda CX-5 2018 SUV familiar. Tracción 4x4, amplio espacio para equipaje, sistema de navegación.',
    caracteristicas: [
      'Tracción 4x4',
      'Sistema de navegación',
      'Quemacocos',
      'Asientos de piel',
      'Rines de aleación',
    ],
  },
  {
    id: '5',
    marca: 'Volkswagen',
    modelo: 'Jetta',
    año: 2019,
    precio: 265000,
    kilometraje: 55000,
    transmision: 'Automática',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1623869675781-80aa31cacc49?w=800&h=600&fit=crop',
    ],
    descripcion: 'Volkswagen Jetta 2019 en perfectas condiciones. Faros LED, asientos de piel, climatizador automático.',
    caracteristicas: [
      'Faros LED',
      'Asientos de piel',
      'Climatizador automático',
      'Bluetooth',
      'Sensores de estacionamiento',
    ],
  },
  {
    id: '6',
    marca: 'Chevrolet',
    modelo: 'Aveo',
    año: 2018,
    precio: 165000,
    kilometraje: 68000,
    transmision: 'Manual',
    combustible: 'Gasolina',
    imagen: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1552519507-cf98d4f5bba3?w=800&h=600&fit=crop',
    ],
    descripcion: 'Chevrolet Aveo 2018 económico y confiable. Ideal para primer auto, fácil de manejar.',
    caracteristicas: [
      'Económico',
      'Aire acondicionado',
      'Radio MP3',
      'Bolsas de aire',
      'Bajo mantenimiento',
    ],
  },
];

export const motos: Moto[] = [
  {
    id: '1',
    marca: 'Yamaha',
    modelo: 'FZ-16',
    año: 2021,
    precio: 38000,
    kilometraje: 8500,
    cilindrada: '150cc',
    imagen: 'https://images.unsplash.com/photo-1558981852-426c6c22a060?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1558981852-426c6c22a060?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1609630875171-b1321377ee65?w=800&h=600&fit=crop',
    ],
    descripcion: 'Yamaha FZ-16 2021 en excelente estado. Ideal para ciudad, bajo consumo de gasolina.',
    caracteristicas: [
      'Bajo consumo',
      'Frenos de disco',
      'Luces LED',
      'Llantas en buen estado',
      'Mantenimiento al día',
    ],
  },
  {
    id: '2',
    marca: 'Honda',
    modelo: 'CB190R',
    año: 2020,
    precio: 42000,
    kilometraje: 12000,
    cilindrada: '190cc',
    imagen: 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1599819177626-c0c4ebbf7642?w=800&h=600&fit=crop',
    ],
    descripcion: 'Honda CB190R 2020 deportiva urbana. Excelente rendimiento, cómoda para viajes largos.',
    caracteristicas: [
      'ABS',
      'Panel digital',
      'Frenos de disco',
      'Suspensión deportiva',
      'Un solo dueño',
    ],
  },
  {
    id: '3',
    marca: 'Italika',
    modelo: 'FT-150',
    año: 2022,
    precio: 22000,
    kilometraje: 4500,
    cilindrada: '150cc',
    imagen: 'https://images.unsplash.com/photo-1609630875252-ae3a1f4b0865?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1609630875252-ae3a1f4b0865?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1558981285-6f0c94958bb6?w=800&h=600&fit=crop',
    ],
    descripcion: 'Italika FT-150 2022 seminueva. Económica y confiable, perfecta para trabajo.',
    caracteristicas: [
      'Económica',
      'Bajo mantenimiento',
      'Porta objetos',
      'Llantas nuevas',
      'Factura original',
    ],
  },
  {
    id: '4',
    marca: 'Suzuki',
    modelo: 'Gixxer',
    año: 2021,
    precio: 45000,
    kilometraje: 9500,
    cilindrada: '155cc',
    imagen: 'https://images.unsplash.com/photo-1605549444127-ec70c7f0aa37?w=800&h=600&fit=crop',
    imagenes: [
      'https://images.unsplash.com/photo-1605549444127-ec70c7f0aa37?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1619204715997-1367fe5812f1?w=800&h=600&fit=crop',
    ],
    descripcion: 'Suzuki Gixxer 2021 deportiva. Motor potente, diseño agresivo, muy bien cuidada.',
    caracteristicas: [
      'Motor potente',
      'Frenos de disco ABS',
      'Panel digital completo',
      'Luces LED',
      'Garantía disponible',
    ],
  },
];
