
  # Rediseño sitio web El Rayo

  This is a code bundle for Rediseño sitio web El Rayo. The original project is available at https://www.figma.com/design/sHHjfEgLvKwqryjo2vHe6E/Redise%C3%B1o-sitio-web-El-Rayo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  